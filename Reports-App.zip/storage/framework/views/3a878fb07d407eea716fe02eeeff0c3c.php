<?php
    $path = $getPath();
    $width = $getWidth();
?>
<img src="<?php echo e($path); ?>" alt="" style="<?php echo e($width->value); ?>">
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\eightynine\filament-reports\resources\views\components\image.blade.php ENDPATH**/ ?>