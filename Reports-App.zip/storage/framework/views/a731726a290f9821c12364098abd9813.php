<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\filament\support\resources\views\components\dropdown\list\index.blade.php ENDPATH**/ ?>