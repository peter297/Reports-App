<th <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</th>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\eightynine\filament-reports\resources\views\components\table\footer-cell.blade.php ENDPATH**/ ?>