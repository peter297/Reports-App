use App\Models\SectionCoordinatorAssignment;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Alameen Academy - Enrollment Report</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #222; }
        .header { text-align: center; margin-bottom: 20px; }
        .logo { width: 100px; height: auto; margin-bottom: 8px; }
        h1 { text-align: center; margin: 0 0 4px 0; color: #1f2937; font-size: 16px; }
        .subtitle { text-align: center; color: #6b7280; font-size: 10px; margin: 0 0 16px 0; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #9ca3af; padding: 6px 8px; vertical-align: top; }
        th { background: #e5e7eb; font-weight: bold; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        .bg-light { background: #f3f4f6; }
        .total-row td { border-top: 2px solid #6b7280; font-weight: bold; background: #f9fafb; }
        .inner-table { width: 100%; border-collapse: collapse; margin: 0; }
        .inner-table th, .inner-table td { border: 1px solid #d1d5db; padding: 4px 6px; font-size: 9px; }
        .inner-table th { background: #f3f4f6; }
        .success { color: #059669; }
        .danger { color: #dc2626; }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo e(public_path('images/alameen-academy-logo.png')); ?>" alt="Alameen Academy Logo" class="logo">
        <h1>Alameen Academy - Enrollment Report</h1>
    </div>
    <table>
        <thead>
            <tr>
                <th>Branch</th>
                <th>Academic Year</th>
                <th>Term</th>
                <th class="text-right">Total Learners</th>
                <th>Learners per Class</th>
                <th class="text-right">Admitted</th>
                <th class="text-right">Left</th>
                <th>Comment</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $classes = $enrollment->class_breakdown ?? [];
                    $grandTotalBoys = collect($classes)->sum('boys');
                    $grandTotalGirls = collect($classes)->sum('girls');
                    $grandTotal = collect($classes)->sum('total');
                    $grandTotalAdmitted = collect($classes)->sum('new_admissions');
                    $grandTotalLeft = collect($classes)->sum('departures');
                ?>
                <tr>
                    <td><?php echo e($enrollment->branch); ?></td>
                    <td><?php echo e($enrollment->yearSession?->name); ?></td>
                    <td><?php echo e($enrollment->term?->name); ?></td>
                    <td class="text-right font-bold"><?php echo e($enrollment->total_learners); ?></td>
                    <td>
                        <?php if($classes): ?>
                            <table class="inner-table">
                                <thead>
                                    <tr>
                                        <th>Class</th>
                                        <th class="text-right">Boys</th>
                                        <th class="text-right">Girls</th>
                                        <th class="text-right">Total</th>
                                        <th class="text-right">Admitted</th>
                                        <th class="text-right">Left</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($class['class_name'] ?? $class['class_id'] ?? 'Class'); ?></td>
                                            <td class="text-right"><?php echo e($class['boys'] ?? 0); ?></td>
                                            <td class="text-right"><?php echo e($class['girls'] ?? 0); ?></td>
                                            <td class="text-right font-bold"><?php echo e($class['total'] ?? ((int) ($class['boys'] ?? 0) + (int) ($class['girls'] ?? 0))); ?></td>
                                            <td class="text-right success"><?php echo e($class['new_admissions'] ?? 0); ?></td>
                                            <td class="text-right danger"><?php echo e($class['departures'] ?? 0); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($classes) > 1): ?>
                                        <tr class="total-row">
                                            <td>Total</td>
                                            <td class="text-right"><?php echo e($grandTotalBoys); ?></td>
                                            <td class="text-right"><?php echo e($grandTotalGirls); ?></td>
                                            <td class="text-right"><?php echo e($grandTotal); ?></td>
                                            <td class="text-right success"><?php echo e($grandTotalAdmitted); ?></td>
                                            <td class="text-right danger"><?php echo e($grandTotalLeft); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <em>No class data</em>
                        <?php endif; ?>
                    </td>
                    <td class="text-right success"><?php echo e($enrollment->new_admissions); ?></td>
                    <td class="text-right danger"><?php echo e($enrollment->departures); ?></td>
                    <td><?php echo e($enrollment->comment); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\resources\views\pdf\enrollments.blade.php ENDPATH**/ ?>