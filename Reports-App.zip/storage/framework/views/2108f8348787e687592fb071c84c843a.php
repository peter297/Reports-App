<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar of Events - <?php echo e($event->name); ?></title>
    <style>
        @page {
            size: A4 landscape;
            margin: 0;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            height: 100%;
            background: #525659;
        }

        .sheet {
            width: 100vw;
            height: 100vh;
        }

        .sheet iframe,
        .sheet img {
            display: block;
            width: 100%;
            height: 100%;
            border: 0;
            object-fit: contain;
            background: #ffffff;
        }

        @media print {
            html,
            body {
                background: #ffffff;
            }

            .sheet {
                width: 100%;
                height: auto;
            }
        }
    </style>
</head>
<body>
    <div class="sheet">
        <?php if($isPdf): ?>
            <iframe src="<?php echo e($url); ?>" title="Calendar of Events - <?php echo e($event->name); ?>"></iframe>
        <?php else: ?>
            <img src="<?php echo e($url); ?>" alt="Calendar of Events - <?php echo e($event->name); ?>">
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\resources\views\events\calendar-preview.blade.php ENDPATH**/ ?>