<td <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\eightynine\filament-reports\resources\views\components\table\cell.blade.php ENDPATH**/ ?>