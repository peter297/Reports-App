<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Alameen Academy - <?php echo e($period_label); ?> Attendance Report</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #222; }
        .header { text-align: center; margin-bottom: 20px; }
        .logo { width: 100px; height: auto; margin-bottom: 8px; }
        h1 { text-align: center; margin: 0 0 4px 0; color: #1f2937; font-size: 16px; }
        .subtitle { text-align: center; color: #6b7280; font-size: 11px; margin: 0 0 16px 0; }
        h3.week-heading { color: #fff; background: #1f2937; font-size: 11px; margin: 18px 0 0 0; padding: 6px 8px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #9ca3af; padding: 5px 6px; }
        th { background: #1f2937; color: #fff; font-weight: bold; font-size: 9px; }
        td { font-size: 9px; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
        .success { color: #059669; }
        .danger { color: #dc2626; }
        .total-row td { border-top: 2px solid #1f2937; font-weight: bold; background: #f3f4f6; }
        tbody tr:nth-child(even) { background: #f9fafb; }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo e(public_path('images/alameen-academy-logo.png')); ?>" alt="Alameen Academy Logo" class="logo">
        <h1>Alameen Academy - <?php echo e($period_label); ?> Attendance Report</h1>
    </div>
    <?php
        $grandTotalLearners = 0;
        $grandTotalPresent = 0;
        $grandTotalAbsent = 0;

        foreach ($rows as $grandRow) {
            $grandTotalLearners += $grandRow['class_total'];
            $grandTotalPresent += $grandRow['total_present'];
            $grandTotalAbsent += $grandRow['total_absent'];
        }

        $grandPercentagePresent = $grandTotalLearners > 0 ? round(($grandTotalPresent / $grandTotalLearners) * 100, 2) : 0;
    ?>
    <?php if(! empty($sections)): ?>
        <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <h3 class="week-heading"><?php echo e($section['label']); ?></h3>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Branch</th>
                        <th>Section</th>
                        <th>Class</th>
                        <th>Stream</th>
                        <th class="text-right">Records</th>
                        <th class="text-right">Total Learners</th>
                        <th class="text-right">Total Present</th>
                        <th class="text-right">Total Absent</th>
                        <th class="text-right">% Present</th>
                        <th class="text-right">% Absent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $section['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row['period_label']); ?></td>
                            <td><?php echo e($row['branch']); ?></td>
                            <td><?php echo e($row['section']); ?></td>
                            <td><?php echo e($row['class_name']); ?></td>
                            <td><?php echo e($row['stream_name']); ?></td>
                            <td class="text-right"><?php echo e($row['record_count']); ?></td>
                            <td class="text-right font-bold"><?php echo e($row['class_total']); ?></td>
                            <td class="text-right success"><?php echo e($row['total_present']); ?></td>
                            <td class="text-right danger"><?php echo e($row['total_absent']); ?></td>
                            <td class="text-right success font-bold"><?php echo e(number_format($row['percentage_present'], 2)); ?>%</td>
                            <td class="text-right danger font-bold"><?php echo e(number_format($row['percentage_absent'], 2)); ?>%</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <?php if(count($section['rows']) > 1): ?>
                    <tfoot>
                        <tr class="total-row">
                            <td colspan="5" class="font-bold"><?php echo e($section['subtotal_label']); ?></td>
                            <td class="text-right font-bold"><?php echo e(count($section['rows'])); ?></td>
                            <td class="text-right font-bold"><?php echo e($section['class_total']); ?></td>
                            <td class="text-right success font-bold"><?php echo e($section['total_present']); ?></td>
                            <td class="text-right danger font-bold"><?php echo e($section['total_absent']); ?></td>
                            <td class="text-right success font-bold"><?php echo e(number_format($section['percentage_present'], 2)); ?>%</td>
                            <td class="text-right danger font-bold"><?php echo e(number_format($section['percentage_absent'], 2)); ?>%</td>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <table>
                <tbody>
                    <tr><td colspan="11" style="text-align: center; color: #6b7280; font-style: italic;">No attendance records found.</td></tr>
                </tbody>
            </table>
        <?php endif; ?>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Period</th>
                    <th>Branch</th>
                    <th>Section</th>
                    <th>Class</th>
                    <th>Stream</th>
                    <th class="text-right">Records</th>
                    <th class="text-right">Total Learners</th>
                    <th class="text-right">Total Present</th>
                    <th class="text-right">Total Absent</th>
                    <th class="text-right">% Present</th>
                    <th class="text-right">% Absent</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($row['period_label']); ?></td>
                        <td><?php echo e($row['branch']); ?></td>
                        <td><?php echo e($row['section']); ?></td>
                        <td><?php echo e($row['class_name']); ?></td>
                        <td><?php echo e($row['stream_name']); ?></td>
                        <td class="text-right"><?php echo e($row['record_count']); ?></td>
                        <td class="text-right font-bold"><?php echo e($row['class_total']); ?></td>
                        <td class="text-right success"><?php echo e($row['total_present']); ?></td>
                        <td class="text-right danger"><?php echo e($row['total_absent']); ?></td>
                        <td class="text-right success font-bold"><?php echo e(number_format($row['percentage_present'], 2)); ?>%</td>
                        <td class="text-right danger font-bold"><?php echo e(number_format($row['percentage_absent'], 2)); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="11" style="text-align: center; color: #6b7280; font-style: italic;">No attendance records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
    <?php if(count($rows) > 1): ?>
        <table style="margin-top: 12px;">
            <tfoot>
                <tr class="total-row">
                    <td colspan="5" class="font-bold">GRAND TOTAL</td>
                    <td class="text-right font-bold"><?php echo e(count($rows)); ?></td>
                    <td class="text-right font-bold"><?php echo e($grandTotalLearners); ?></td>
                    <td class="text-right success font-bold"><?php echo e($grandTotalPresent); ?></td>
                    <td class="text-right danger font-bold"><?php echo e($grandTotalAbsent); ?></td>
                    <td class="text-right success font-bold"><?php echo e(number_format($grandPercentagePresent, 2)); ?>%</td>
                    <td class="text-right danger font-bold"><?php echo e(number_format(100 - $grandPercentagePresent, 2)); ?>%</td>
                </tr>
            </tfoot>
        </table>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\resources\views\pdf\attendance-report.blade.php ENDPATH**/ ?>