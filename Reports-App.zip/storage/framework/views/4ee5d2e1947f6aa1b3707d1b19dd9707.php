<thead <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</thead>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\eightynine\filament-reports\resources\views\components\table\head.blade.php ENDPATH**/ ?>