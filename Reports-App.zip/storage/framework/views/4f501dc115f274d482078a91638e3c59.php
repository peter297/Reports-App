<?php $__currentLoopData = $getComponents(withHidden: true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportComponent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($reportComponent); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\eightynine\filament-reports\resources\views\component-container.blade.php ENDPATH**/ ?>