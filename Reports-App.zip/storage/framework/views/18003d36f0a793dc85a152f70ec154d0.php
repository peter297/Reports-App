<div
    <?php echo e($attributes->class(['fi-fo-field-wrp-helper-text break-words text-sm text-gray-500'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\filament\forms\resources\views\components\field-wrapper\helper-text.blade.php ENDPATH**/ ?>