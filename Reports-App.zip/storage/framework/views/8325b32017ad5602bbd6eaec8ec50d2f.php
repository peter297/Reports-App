<tbody <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\eightynine\filament-reports\resources\views\components\table\body.blade.php ENDPATH**/ ?>