<table
    <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</table>
<?php /**PATH C:\Users\Peter Kimani\Herd\Reports-App\vendor\eightynine\filament-reports\resources\views\components\table\index.blade.php ENDPATH**/ ?>