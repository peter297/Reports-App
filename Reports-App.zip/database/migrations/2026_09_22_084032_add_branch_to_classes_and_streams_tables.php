<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('classes', function (Blueprint $table) {
            $table->string('branch')->nullable()->after('name');
        });

        Schema::table('streams', function (Blueprint $table) {
            $table->string('branch')->nullable()->after('name');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('streams', function (Blueprint $table) {
            $table->dropColumn('branch');
        });

        Schema::table('classes', function (Blueprint $table) {
            $table->dropColumn('branch');
        });
    }
};
